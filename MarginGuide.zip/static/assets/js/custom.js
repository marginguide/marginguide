
// 모달 클로즈
function myFunction() { document.getElementById("modal_close").click(); };

// 차일드 메뉴 내리기
function colip() {
    var submenu = document.getElementById("settingMenu");
    if (submenu.style.display === "block") {
        submenu.style.display = "none";
    } else {
        submenu.style.display = "block";
    }
    if (submenu.style.maxHeight) {
        submenu.style.maxHeight = null; // 닫기
    } else {
        submenu.style.maxHeight = submenu.scrollHeight + "px"; // 열기
    }
};

// 차일드 메뉴 내리기
function colip_mapas() {
    var submenu = document.getElementById("settingMenu_mapas");
    if (submenu.style.display === "block") {
        submenu.style.display = "none";
    } else {
        submenu.style.display = "block";
    }
    if (submenu.style.maxHeight) {
        submenu.style.maxHeight = null; // 닫기
    } else {
        submenu.style.maxHeight = submenu.scrollHeight + "px"; // 열기
    }
};

// 알림 모달
var alertTimeout; // 자동 숨김 타이머 변수

function short_showCustomAlert(message) {
    var alertBox = document.getElementById("customAlert");
    alertBox.innerHTML = message;
    alertBox.style.display = "block";
    setTimeout(() => { alertBox.style.opacity = "1"; }, 10); // 부드럽게 나타남

    // 3초 후 자동으로 사라짐
    alertTimeout = setTimeout(hideCustomAlert, 2000);
}

function long_showCustomAlert(message) {
    var alertBox = document.getElementById("customAlert");
    alertBox.innerHTML = message;
    alertBox.style.display = "block";
    setTimeout(() => { alertBox.style.opacity = "1"; }, 10); // 부드럽게 나타남

    // 3초 후 자동으로 사라짐
    alertTimeout = setTimeout(hideCustomAlert, 10000);
}

function hideCustomAlert() {
    var alertBox = document.getElementById("customAlert");
    clearTimeout(alertTimeout); // 기존 타이머 취소 (클릭 시 즉시 사라지게)
    alertBox.style.opacity = "0";

    setTimeout(() => { 
        alertBox.style.display = "none"; 
    }, 500); // transition과 동일한 시간
}


function startLoading() {
    // 요소 가져오기
    var button = document.getElementById('rankingButton');
    var loadingSpinner = document.getElementById('loadingSpinner');

    // 버튼 비활성화
    button.style.display = 'none';


    // 로딩 스피너 표시
    loadingSpinner.style.display = 'inline-block';

    // today_ranking() 함수 실행
    $.ajax({
        type: "GET",
        url: "/today_ranking",
        success: function(response) {
            long_showCustomAlert(response);
            // 작업 완료 후 버튼 활성화
            button.style.display = 'block';
            loadingSpinner.style.display = 'none';
        },
    }),
    console.error('Error:', error);
    // 에러 발생 시에도 버튼 활성화
    button.style.display = 'block';
    loadingSpinner.style.display = 'none';
}

function goBack() {
    window.history.back();
}

function goForward() {
    window.history.forward();
}

var color_0 = "rgba(234,85,69, 0.7)"
var color_1 = "rgba(39,174,239, 0.7)"
var color_2 = "rgba(81,151,70, 0.7)"
var color_3 = "rgba(134,84,67, 0.7)"
var color_4 = "rgba(98,76,134, 0.7)"
var color_5 = "rgba(251,112,27, 0.7)"
var color_6 = "rgba(174,216,132, 0.7)"
var color_7 = "rgba(192,170,208, 0.7)"
var color_8 = "rgba(252,180,106, 0.7)"
var color_9 = "rgba(156,201,222, 0.7)"
var color_10 = "rgba(247,143,144, 0.7)"
var color_11 = "rgba(219,213,17, 0.7)"
var color_12 = "rgba(183,183,183, 0.7)"
